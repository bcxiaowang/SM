package cn.ming.crypto;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Arrays;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import org.bouncycastle.math.ec.ECPoint;

import com.yy.Main;
import com.yy.gm.sm9.G1KeyPair;
import com.yy.gm.sm9.KGC;
import com.yy.gm.sm9.MasterKeyPair;
import com.yy.gm.sm9.PrivateKey;
import com.yy.gm.sm9.PrivateKeyType;
import com.yy.gm.sm9.ResultCipherText;
import com.yy.gm.sm9.ResultEncapsulate;
import com.yy.gm.sm9.ResultEncapsulateCipherText;
import com.yy.gm.sm9.ResultKeyExchange;
import com.yy.gm.sm9.ResultSignature;
import com.yy.gm.sm9.SM9;
import com.yy.gm.sm9.SM9Curve;
import com.yy.gm.sm9.SM9Utils;
import com.yy.gm.sm9.SM9WithStandardTestKey;
import com.zuc.Converter;
import com.zuc.ProductKey;

import cn.ming.crypto.SM2.KeyExchange;
import cn.ming.crypto.SM2.Signature;
import cn.ming.crypto.SM2.TransportEntity;

class SelectPathListener implements ActionListener {
	private Component parent;

	public SelectPathListener(Component parent) {
		this.parent = parent;
	}

	private String prikeyPath;
	private String pubkeyPath;
	private JTextArea priTextArea;
	private JTextArea pubTextArea;

	@Override
	public void actionPerformed(ActionEvent e) {
		JFileChooser jf = new JFileChooser();
		jf.showOpenDialog(this.parent);// 显示打开的文件对话框
		File f = jf.getSelectedFile();// 使用文件类获取选择器选择的文件
		if (f != null) { // 选择文件时如果取消则 f 为 null
			if (e.getActionCommand().equals("pubkey")) {
				pubkeyPath = f.getAbsolutePath();// 返回绝对路径名
				System.out.println("公钥绝对路径：" + pubkeyPath);
				if (pubTextArea != null) {
					pubTextArea.setText(pubkeyPath);
				}
			}
			if (e.getActionCommand().equals("prikey")) {
				prikeyPath = f.getAbsolutePath();// 返回绝对路径名
				System.out.println("私钥绝对路径：" + prikeyPath);
				if (priTextArea != null) {
					priTextArea.setText(prikeyPath);
				}
			}
		}

	}

	public void setPriTextArea(JTextArea priTextArea) {
		this.priTextArea = priTextArea;
	}

	public void setPubTextArea(JTextArea pubTextArea) {
		this.pubTextArea = pubTextArea;
	}
}

public class UI extends JFrame {
	private JTabbedPane tabbedPane;
	private JTabbedPane sm9TabbedPane;
	private JTabbedPane zucTabbedPane;
	private JLabel label1, label2, label3; // SM2 3 4 9
	private JPanel panel1, panel2, panel3; // SM2 3 4对应的panel
	private JPanel panelSM9Sign, panelSM9Encrypt, panelSM9KeyEncap, panelSM9Exchange, panelzuc; // SM2
	// 3
	// 4对应的panel
	private SelectPathListener selectPathListener;
	private GridBagConstraints constraints;
	private ResultSignature signature = null;
	private ResultEncapsulate keyEncapsulation;

	private PrivateKey encryptrivateKey = null;
	private ResultCipherText resultCipherText = null;
	// 密钥交换用到
	private PrivateKey aPrivateKey = null;
	private PrivateKey bPrivateKey = null;

	public PrivateKey getaPrivateKey() {
		return aPrivateKey;
	}

	public void setaPrivateKey(PrivateKey aPrivateKey) {
		this.aPrivateKey = aPrivateKey;
	}

	public PrivateKey getbPrivateKey() {
		return bPrivateKey;
	}

	public void setbPrivateKey(PrivateKey bPrivateKey) {
		this.bPrivateKey = bPrivateKey;
	}

	public ResultSignature getSignature() {
		return signature;
	}

	public void setSignature(ResultSignature signature) {
		this.signature = signature;
	}

	public PrivateKey getEncryptrivateKey() {
		return encryptrivateKey;
	}

	public void setEncryptrivateKey(PrivateKey encryptrivateKey) {
		this.encryptrivateKey = encryptrivateKey;
	}

	public ResultCipherText getResultCipherText() {
		return resultCipherText;
	}

	public void setResultCipherText(ResultCipherText resultCipherText) {
		this.resultCipherText = resultCipherText;
	}

	public UI() {
		super("国密算法小程序");
		setSize(800, 900);

		Container c = getContentPane();
		tabbedPane = new JTabbedPane(); // 创建选项卡面板对象
		sm9TabbedPane = new JTabbedPane();
		zucTabbedPane = new JTabbedPane();
		constraints = new GridBagConstraints();
		// 创建标签
		// label1=new JLabel("第一个标签的面板",SwingConstants.CENTER);
		// label2=new JLabel("第二个标签的面板",SwingConstants.CENTER);
		// label3=new JLabel("第三个标签的面板",SwingConstants.CENTER);
		label1 = new JLabel();
		label2 = new JLabel();
		label3 = new JLabel();
		// label4=new JLabel();
		// 创建面板
		panel1 = new JPanel();
		panel2 = new JPanel();
		panel3 = new JPanel();
		panelSM9Sign = new JPanel();
		panelSM9Encrypt = new JPanel();
		panelSM9KeyEncap = new JPanel();
		panelSM9Exchange = new JPanel();
		panelzuc = new JPanel();
		panel1.add(label1);
		panel2.add(label2);
		panel3.add(label3);
		// panel4.add(label3);

		// panel1.setBackground(Color.red);
		// panel2.setBackground(Color.green);
		// panel3.setBackground(Color.yellow);

		// 将标签面板加入到选项卡面板对象上
		tabbedPane.addTab("SM2", null, panel1, "First panel");
		tabbedPane.addTab("SM3", null, panel2, "Second panel");
		tabbedPane.addTab("SM4", null, panel3, "Third panel");
		tabbedPane.add("SM9", sm9TabbedPane);
		tabbedPane.add("ZUC", zucTabbedPane);
		sm9TabbedPane.addTab("SM9-签名", panelSM9Sign);
		sm9TabbedPane.addTab("SM9-加解密", panelSM9Encrypt);
		sm9TabbedPane.addTab("SM9-密钥封装", panelSM9KeyEncap);
		sm9TabbedPane.addTab("SM9-密钥交换", panelSM9Exchange);
		zucTabbedPane.addTab("ZUC", panelzuc);
		this.add(tabbedPane);
		this.setBackground(Color.white);

		// 初始化路径设置按钮的监听器
		selectPathListener = new SelectPathListener(this);

		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	private void SM2Frame() {
		// 创建button、label、TextArea
		final JButton button1 = new JButton("加密");
		final JButton button2 = new JButton("解密");
		final JButton button3 = new JButton("签名");
		final JButton button4 = new JButton("验签");
		final JButton button5 = new JButton("密钥协商");
		final JButton button6 = new JButton("加密");
		final JButton button7 = new JButton("解密");
		final JButton button8 = new JButton("清空");
		final JButton button9 = new JButton("返回SM2选项");
		final JButton button10 = new JButton("签名");
		final JButton button11 = new JButton("验证");
		final JButton button12 = new JButton("开始协商");
		final JButton button13 = new JButton("选择SM2公钥文件");
		button13.setActionCommand("pubkey");
		button13.addActionListener(selectPathListener);
		final JButton button14 = new JButton("选择SM2私钥文件");
		button14.setActionCommand("prikey");
		button14.addActionListener(selectPathListener);

		final JLabel label1 = new JLabel("在下面输入待处理数据：");
		final JLabel label2 = new JLabel("加密结果如下:\n");
		final JLabel label3 = new JLabel("解密结果:");
		final JLabel label4 = new JLabel("用户标识:");
		final JLabel label5 = new JLabel("数字签名:");
		final JLabel label6 = new JLabel("数字签名:");
		final JLabel label7 = new JLabel("验证结果:");
		final JLabel label8 = new JLabel("公钥路径:");
		final JLabel label9 = new JLabel("私钥路径:");
		final JTextArea textarea1 = new JTextArea(6, 35);
		final JTextArea textarea2 = new JTextArea(6, 35);
		final JTextArea textarea3 = new JTextArea(6, 35);
		final JTextArea textarea4 = new JTextArea(6, 35);

		// 加密时的路径
		final JTextArea textarea5 = new JTextArea(2, 35);
		final JTextArea textarea6 = new JTextArea(2, 35);

		// 自本区域动换行
		textarea1.setLineWrap(true);
		textarea2.setLineWrap(true);
		textarea3.setLineWrap(true);
		textarea4.setLineWrap(true);

		// 添加button
		panel1.add(button1);
		panel1.add(button2);
		panel1.add(button3);
		panel1.add(button4);
		panel1.add(button5);
		panel1.add(label8);
		panel1.add(textarea5);
		panel1.add(label9);
		panel1.add(textarea6);
		panel1.add(label1);
		panel1.add(textarea1);
		panel1.add(label4);
		panel1.add(textarea3);
		panel1.add(label6);
		panel1.add(textarea4);
		panel1.add(button6);
		panel1.add(button7);
		panel1.add(button8);
		panel1.add(button9);
		panel1.add(button10);
		panel1.add(button11);
		panel1.add(button12);
		panel1.add(button13);
		panel1.add(button14);
		panel1.add(label2);
		panel1.add(label3);
		panel1.add(label5);
		panel1.add(label7);
		panel1.add(textarea2);
		/*
		 * // 行 constraints.insets = new Insets(10, 0, 0, 0); constraints.fill =
		 * GridBagConstraints.HORIZONTAL; constraints.weightx = 0.1;
		 * constraints.gridx = 0; constraints.gridy = 0; panel1.add(label8,
		 * constraints);
		 * 
		 * constraints.weightx = 0.9; constraints.gridx = 1; constraints.gridy =
		 * 0; constraints.gridwidth = 3; constraints.ipady = 5;
		 * panel1.add(textarea5, constraints);
		 * 
		 * constraints.weightx = 0.1; constraints.gridx = 0; constraints.gridy =
		 * 1; constraints.ipady = 50; panel1.add(label2, constraints);
		 * 
		 * constraints.weightx = 0.9; constraints.gridx = 1; constraints.gridy =
		 * 1; constraints.gridwidth = 3; constraints.ipady = 10;
		 * panel1.add(textarea2, constraints);
		 * 
		 * // 按钮 constraints.ipady = 0; constraints.fill =
		 * GridBagConstraints.HORIZONTAL; constraints.weightx = 0.2;
		 * constraints.gridx = 0; constraints.gridy = 8; constraints.gridwidth =
		 * 1; panel1.add(button6, constraints);
		 * 
		 * constraints.weightx = 0.2; constraints.gridx = 1; constraints.gridy =
		 * 8; constraints.gridwidth = 1; panel1.add(button8, constraints);
		 * 
		 * constraints.weightx = 0.2; constraints.gridx = 2; constraints.gridy =
		 * 8; constraints.gridwidth = 1; panel1.add(button9, constraints);
		 * 
		 * constraints.weightx = 0.2; constraints.gridx = 3; constraints.gridy =
		 * 8; constraints.gridwidth = 1; panel1.add(button13, constraints);
		 */

		button1.setVisible(true);
		button2.setVisible(true);
		button3.setVisible(true);
		button4.setVisible(true);
		button5.setVisible(true);
		button6.setVisible(false);
		button7.setVisible(false);
		button8.setVisible(false);
		button9.setVisible(false);
		button10.setVisible(false);
		button11.setVisible(false);
		button12.setVisible(false);
		button13.setVisible(false);
		button14.setVisible(false);
		textarea1.setVisible(false);
		textarea2.setVisible(false);
		textarea3.setVisible(false);
		textarea4.setVisible(false);
		textarea5.setVisible(false);
		textarea6.setVisible(false);
		label1.setVisible(false);
		label2.setVisible(false);
		label3.setVisible(false);
		label4.setVisible(false);
		label5.setVisible(false);
		label6.setVisible(false);
		label7.setVisible(false);
		label8.setVisible(false);
		label9.setVisible(false);

		// 选择加密
		ActionListener C = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				button1.setVisible(false);
				button2.setVisible(false);
				button3.setVisible(false);
				button4.setVisible(false);
				button5.setVisible(false);
				button6.setVisible(true);//
				button7.setVisible(false);
				button8.setVisible(true);//
				button9.setVisible(true);//
				button13.setVisible(true);//
				button14.setVisible(false);
				button10.setVisible(false);
				button11.setVisible(false);
				button12.setVisible(false);
				textarea1.setVisible(true);//
				textarea2.setVisible(true);//
				textarea3.setVisible(false);
				textarea4.setVisible(false);
				textarea5.setVisible(true);//
				label1.setVisible(true);//
				label2.setVisible(true);//
				label3.setVisible(false);
				label4.setVisible(false);
				label5.setVisible(false);
				label6.setVisible(false);
				label7.setVisible(false);
				label8.setVisible(true);//
				label9.setVisible(false);

				selectPathListener.setPubTextArea(textarea5);

				textarea6.setVisible(false);

				textarea1.setText("");
				textarea2.setText("");
				textarea3.setText("");
				textarea4.setText("");
				textarea5.setText("");
				textarea6.setText("");
			}
		};
		button1.addActionListener(C);

		// 加密
		ActionListener I = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				button1.setVisible(false);
				button2.setVisible(false);
				button3.setVisible(false);
				button4.setVisible(false);
				button5.setVisible(false);
				button6.setVisible(true);
				button7.setVisible(false);
				button8.setVisible(true);
				button9.setVisible(true);
				button10.setVisible(false);
				button11.setVisible(false);
				button12.setVisible(false);
				button13.setVisible(true);
				textarea1.setVisible(true);
				textarea2.setVisible(true);
				textarea3.setVisible(false);
				textarea4.setVisible(false);
				label1.setVisible(true);
				label2.setVisible(true);
				label3.setVisible(false);
				label4.setVisible(false);
				label5.setVisible(false);
				label6.setVisible(false);
				label7.setVisible(false);
				label8.setVisible(true);
				label9.setVisible(false);
				textarea5.setVisible(true);
				textarea6.setVisible(false);

				SM2 sm02 = new SM2();
				/* 从文件导入密钥对或者直接输入路径 */
				String path = textarea5.getText();
				System.out.println("公钥路径:\n" + path);

				ECPoint pubKey = sm02.importPublicKey(path);
				String rb = SM2.getHexString(pubKey.getRawXCoord().getEncoded());
				System.out.println("公钥:\n" + rb);
				/* 加密 */
				String plainText = textarea1.getText();
				byte[] data = sm02.encrypt(plainText, pubKey);
				String ciphertext = SM2.getHexString(data);
				textarea2.setText(ciphertext);

			}
		};
		button6.addActionListener(I);

		// 选择解密
		ActionListener D = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				button1.setVisible(false);
				button2.setVisible(false);
				button3.setVisible(false);
				button4.setVisible(false);
				button5.setVisible(false);
				button6.setVisible(false);
				button7.setVisible(true);
				button8.setVisible(true);
				button9.setVisible(true);
				button10.setVisible(false);
				button11.setVisible(false);
				button12.setVisible(false);
				button13.setVisible(false);
				button14.setVisible(true);
				textarea1.setVisible(true);
				textarea2.setVisible(true);
				textarea3.setVisible(false);
				textarea4.setVisible(false);
				label1.setVisible(true);
				label2.setVisible(false);
				label3.setVisible(true);
				label4.setVisible(false);
				label5.setVisible(false);
				label6.setVisible(false);
				label7.setVisible(false);
				label8.setVisible(false);
				label9.setVisible(true);
				textarea5.setVisible(false);
				textarea6.setVisible(true);
				selectPathListener.setPriTextArea(textarea6);
				textarea1.setText("");
				textarea2.setText("");
				textarea3.setText("");
				textarea4.setText("");
				textarea5.setText("");
				textarea6.setText("");
			}
		};
		button2.addActionListener(D);

		// 解密
		ActionListener J = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				button1.setVisible(false);
				button2.setVisible(false);
				button3.setVisible(false);
				button4.setVisible(false);
				button5.setVisible(false);
				button6.setVisible(false);
				button7.setVisible(true);
				button8.setVisible(true);
				button9.setVisible(true);
				button10.setVisible(false);
				button11.setVisible(false);
				button12.setVisible(false);
				textarea1.setVisible(true);
				textarea2.setVisible(true);
				textarea3.setVisible(false);
				textarea4.setVisible(false);
				label1.setVisible(true);
				label2.setVisible(false);
				label3.setVisible(true);
				label4.setVisible(false);
				label5.setVisible(false);
				label6.setVisible(false);
				label7.setVisible(false);
				label8.setVisible(false);
				label9.setVisible(true);
				textarea5.setVisible(false);
				textarea6.setVisible(true);

				String data = textarea1.getText();

				byte[] ciphertext = SM2.hexStringToBytes(data);
				SM2 sm02 = new SM2();
				/* 也可以从文件导入密钥对 */
				String path = textarea6.getText();
				// SM2 的私钥是一个大整数
				BigInteger privKey = sm02.importPrivateKey(path);
				System.out.println("私钥: " + privKey);
				/* 解密 */
				String plainText = sm02.decrypt(ciphertext, privKey);
				textarea2.setText(plainText);

			}
		};
		button7.addActionListener(J);

		// 选择签名
		ActionListener E = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				button1.setVisible(false);
				button2.setVisible(false);
				button3.setVisible(false);
				button4.setVisible(false);
				button5.setVisible(false);
				button6.setVisible(false);
				button7.setVisible(false);
				button8.setVisible(true);
				button9.setVisible(true);
				button10.setVisible(true);
				button11.setVisible(false);
				button12.setVisible(false);
				textarea1.setVisible(true);
				textarea2.setVisible(true);
				textarea3.setVisible(true);
				textarea4.setVisible(false);
				label1.setVisible(true);
				label2.setVisible(false);
				label3.setVisible(false);
				label4.setVisible(true);
				label5.setVisible(true);
				label6.setVisible(false);
				label7.setVisible(false);
				label8.setVisible(true);
				label9.setVisible(true);
				textarea5.setVisible(true);
				textarea6.setVisible(true);

				textarea1.setText("");
				textarea2.setText("");
				textarea3.setText("");
				textarea4.setText("");
				textarea5.setText("");
				textarea6.setText("");
			}
		};
		button3.addActionListener(E);

		// 签名
		ActionListener Y = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				button1.setVisible(false);
				button2.setVisible(false);
				button3.setVisible(false);
				button4.setVisible(false);
				button5.setVisible(false);
				button6.setVisible(false);
				button7.setVisible(false);
				button8.setVisible(true);
				button9.setVisible(true);
				button10.setVisible(true);
				button11.setVisible(false);
				button12.setVisible(false);
				textarea1.setVisible(true);
				textarea2.setVisible(true);
				textarea3.setVisible(true);
				textarea4.setVisible(false);
				label1.setVisible(true);
				label2.setVisible(false);
				label3.setVisible(false);
				label4.setVisible(true);
				label5.setVisible(true);
				label6.setVisible(false);
				label7.setVisible(false);
				label8.setVisible(true);
				label9.setVisible(true);
				textarea5.setVisible(true);
				textarea6.setVisible(true);

				SM2 sm02 = new SM2();

				/* 也可以从文件导入密钥对 */
				String pubPath = textarea5.getText();
				String priPath = textarea6.getText();
				ECPoint pubKey = sm02.importPublicKey(pubPath);
				BigInteger privKey = sm02.importPrivateKey(priPath);
				// System.out.println("私钥:\n" + privKey.toString(16));

				// ----------------------------------获取用户输入的IDA与待签名的消息M------------------------------------------//

				String IDA = textarea3.getText();
				String M = textarea1.getText();

				Signature signature = sm02.sign(M, IDA, new SM2KeyPair(pubKey, privKey));

				// System.out.println("用户标识:" + signature.r.toString(16));
				// System.out.println("用户标识:" + signature.r.toString(16));
				String sign = IDA + ",(" + signature.r.toString(16).toUpperCase() + ","
						+ signature.s.toString(16).toUpperCase() + ")";

				// ------------------------------将签名信息写到结果文本框中---------------------------------------------------//
				textarea2.setText(sign);
				//
				//
				// System.out.println("用户标识:" + IDA);
				// System.out.println("签名信息:" + M);
				// System.out.println("数字签名:" + signature);

			}
		};
		button10.addActionListener(Y);

		// 选择验签
		ActionListener F = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				button1.setVisible(false);
				button2.setVisible(false);
				button3.setVisible(false);
				button4.setVisible(false);
				button5.setVisible(false);
				button6.setVisible(false);
				button7.setVisible(false);
				button8.setVisible(true);
				button9.setVisible(true);
				button10.setVisible(false);
				button11.setVisible(true);
				button12.setVisible(false);
				textarea1.setVisible(true);
				textarea2.setVisible(true);
				textarea3.setVisible(true);
				textarea4.setVisible(true);
				label1.setVisible(true);
				label2.setVisible(false);
				label3.setVisible(false);
				label4.setVisible(true);
				label5.setVisible(false);
				label6.setVisible(true);
				label7.setVisible(true);
				label8.setVisible(true);
				label9.setVisible(false);
				textarea5.setVisible(true);
				textarea6.setVisible(false);

				textarea1.setText("");
				textarea2.setText("");
				textarea3.setText("");
				textarea4.setText("");
				textarea5.setText("");
				textarea6.setText("");

			}
		};
		button4.addActionListener(F);

		// 验签
		ActionListener Z = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				button1.setVisible(false);
				button2.setVisible(false);
				button3.setVisible(false);
				button4.setVisible(false);
				button5.setVisible(false);
				button6.setVisible(false);
				button7.setVisible(false);
				button8.setVisible(true);
				button9.setVisible(true);
				button10.setVisible(false);
				button11.setVisible(true);
				button12.setVisible(false);
				textarea1.setVisible(true);
				textarea2.setVisible(true);
				textarea3.setVisible(true);
				textarea4.setVisible(true);
				label1.setVisible(true);
				label2.setVisible(false);
				label3.setVisible(false);
				label4.setVisible(true);
				label5.setVisible(false);
				label6.setVisible(true);
				label7.setVisible(true);
				label8.setVisible(true);
				label9.setVisible(false);
				textarea5.setVisible(true);
				textarea6.setVisible(false);

				SM2 sm02 = new SM2();

				/* 也可以从文件导入密钥对 */
				String pubPath = textarea5.getText();
				ECPoint pubKey = sm02.importPublicKey(pubPath);

				// ---------------------获取用户输入的待验证消息M、用户标识IDA、待验证签名信息signature1--------------------------//
				String M = textarea1.getText();
				String IDA = textarea3.getText();
				String signTemp = textarea4.getText();

				// String
				// signTemp="(7caa05f622db19cf1151d3bcd645a581386a08d31d5e6e70f3b9c228589bb4cb,576d66f0e0120d88a05099e0de757e07688f71f1e5da4e883a45f9191d35074)";
				signTemp = signTemp.replace("(", "");
				signTemp = signTemp.replace(")", "");

				String signRS[] = signTemp.split(",");

				System.out.println(signRS[0]);
				BigInteger r = new BigInteger(signRS[0], 16);
				BigInteger s = new BigInteger(signRS[1], 16);

				Signature signature = new Signature(r, s);

				System.out.println("验证签名:" + sm02.verify(M, signature, IDA, pubKey));

				// sm02.verify(M, signature, IDA, publicKey));

				System.out.println("用户标识:" + IDA);
				System.out.println("签名信息:" + M);
				System.out.println("数字签名:" + signature);
				System.out.println("验证签名:" + sm02.verify(M, signature, IDA, pubKey));

				if (sm02.verify(M, signature, IDA, pubKey)) {
					String flag = "true";
					textarea2.setText(flag);
				} else {
					String flag = "false";
					textarea2.setText(flag);
				}

			}
		};
		button11.addActionListener(Z);

		// 密钥协商
		ActionListener G = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				button1.setVisible(false);
				button2.setVisible(false);
				button3.setVisible(false);
				button4.setVisible(false);
				button5.setVisible(false);
				button6.setVisible(false);
				button7.setVisible(false);
				button12.setVisible(true);
				button8.setVisible(false);
				button9.setVisible(true);
				button10.setVisible(false);
				button11.setVisible(false);
				button12.setVisible(true);
				textarea1.setVisible(true);
				textarea2.setVisible(true);
				label8.setVisible(false);
				label9.setVisible(false);
				textarea5.setVisible(false);
				textarea6.setVisible(false);

				textarea1.setText("");
				textarea2.setText("");
			}
		};
		button5.addActionListener(G);

		// 开始协商
		ActionListener TalkA = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				button1.setVisible(false);
				button2.setVisible(false);
				button3.setVisible(false);
				button4.setVisible(false);
				button5.setVisible(false);
				button6.setVisible(false);
				button7.setVisible(false);
				button12.setVisible(true);
				button8.setVisible(false);
				button9.setVisible(true);
				button10.setVisible(false);
				button11.setVisible(false);
				textarea1.setVisible(true);
				textarea2.setVisible(true);
				label8.setVisible(false);
				label9.setVisible(false);
				textarea5.setVisible(false);
				textarea6.setVisible(false);

				textarea1.setText("我是用户A\r\n");
				textarea2.setText("我是用户B\r\n");

				SM2 sm02 = new SM2();

				// A进行初始化
				String aID = "ALICE123@YAHOO.COM";
				textarea1.append("我的ID为：" + aID + "\r\n");
				SM2KeyPair aKeyPair = sm02.generateKeyPair();
				KeyExchange aKeyExchange = new KeyExchange(aID, aKeyPair);

				// B进行初始化
				String bID = "BILL456@YAHOO.COM";
				textarea2.append("我的ID为：" + bID + "\r\n");
				SM2KeyPair bKeyPair = sm02.generateKeyPair();
				KeyExchange bKeyExchange = new KeyExchange(bID, bKeyPair);

				// A先生成entity1 发送RA
				TransportEntity entity1 = aKeyExchange.keyExchange_1();
				ECPoint aRTemp = aKeyExchange.RA;
				String ra = SM2.getHexString(aRTemp.getRawXCoord().getEncoded());
				textarea1.append("RA为：" + ra + "\r\n");

				// B拿到entity1 算出密钥 生成entity2 返回RB
				TransportEntity entity2 = bKeyExchange.keyExchange_2(entity1);
				byte[] bkeyTemp = bKeyExchange.key;
				String bkeyString = SM2.getHexString(bkeyTemp);
				textarea2.append("B得到密钥：" + bkeyString + "\r\n");
				ECPoint bRTemp = bKeyExchange.RA;
				String rb = SM2.getHexString(bRTemp.getRawXCoord().getEncoded());
				textarea2.append("RB为：" + rb + "\r\n");
				// A拿到entity2 算出密钥 生成entity3
				TransportEntity entity3 = aKeyExchange.keyExchange_3(entity2);
				byte[] akeyTemp = bKeyExchange.key;
				String akeyString = SM2.getHexString(akeyTemp);
				textarea1.append("A得到密钥：" + akeyString + "\r\n");
				// B拿到entity3 确认密钥
				bKeyExchange.keyExchange_4(entity3);

			}
		};
		button12.addActionListener(TalkA);

		// 清空
		ActionListener clean = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				textarea1.setText("");
				textarea2.setText("");
				textarea3.setText("");
				textarea4.setText("");
				// textarea5.setText("");
				textarea6.setText("");
			}
		};
		button8.addActionListener(clean);

		// 返回SM2
		ActionListener RESM2 = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				button1.setVisible(true);
				button2.setVisible(true);
				button3.setVisible(true);
				button4.setVisible(true);
				button5.setVisible(true);
				button6.setVisible(false);
				button7.setVisible(false);
				button8.setVisible(false);
				button9.setVisible(false);
				button10.setVisible(false);
				button11.setVisible(false);
				button12.setVisible(false);
				button13.setVisible(false);
				button14.setVisible(false);
				textarea1.setVisible(false);
				textarea2.setVisible(false);
				textarea3.setVisible(false);
				textarea4.setVisible(false);
				label1.setVisible(false);
				label2.setVisible(false);
				label3.setVisible(false);
				label4.setVisible(false);
				label5.setVisible(false);
				label6.setVisible(false);
				label7.setVisible(false);
				label8.setVisible(false);
				label9.setVisible(false);
				textarea5.setVisible(false);
				textarea6.setVisible(false);
			}
		};
		button9.addActionListener(RESM2);
	}

	private void SM3Frame() {

		final JTextArea textarea1 = new JTextArea(10, 35);
		final JTextArea textarea2 = new JTextArea(10, 35);
		textarea2.setLineWrap(true);
		JButton button1 = new JButton("加密");
		JButton button2 = new JButton("清空");
		JLabel label1 = new JLabel("加密结果：");

		panel2.add(textarea1);
		panel2.add(button1);
		panel2.add(button2);
		panel2.add(label1);
		panel2.add(textarea2);

		ActionListener E = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				// --------------------------------------获取用户输入-----------------------------------------------//
				String plaintext = textarea1.getText();
				byte[] input;
				try {
					input = cn.ming.crypto.SM3.hash(plaintext.getBytes());
					String ciphertext = cn.ming.crypto.SM3.byteArrayToHexString(input);
					textarea2.setText(ciphertext);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		};
		button1.addActionListener(E);

		ActionListener clean = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				textarea1.setText("");
				textarea2.setText("");
			}
		};
		button2.addActionListener(clean);
	}

	private void SM4Frame() {
		final JButton button1 = new JButton("ECB模式");
		final JButton button2 = new JButton("CBC模式");
		final JButton button3 = new JButton("加密ECB");
		final JButton button4 = new JButton("加密CBC");
		final JButton button5 = new JButton("解密ECB");
		final JButton button6 = new JButton("解密CBC");
		final JButton button7 = new JButton("清空");
		final JButton button8 = new JButton("返回SM4选项");
		final JLabel label1 = new JLabel("加密结果：");
		final JLabel label2 = new JLabel("解密结果：");
		final JLabel label3 = new JLabel("待处理数据：");
		final JLabel label4 = new JLabel("密钥：");
		final JLabel label5 = new JLabel("IV值：");
		final JTextArea textarea = new JTextArea(20, 35);
		final JTextArea key = new JTextArea(2, 10);
		final JTextArea iv = new JTextArea(2, 10);
		final JTextArea output = new JTextArea(20, 35);
		panel3.add(button1);
		panel3.add(button2);
		panel3.add(label3);
		panel3.add(textarea);
		panel3.add(label4);
		panel3.add(key);
		panel3.add(label5);
		panel3.add(iv);
		panel3.add(button3);
		panel3.add(button4);
		panel3.add(button5);
		panel3.add(button6);
		panel3.add(button7);
		panel3.add(button8);
		panel3.add(label1);
		panel3.add(label2);
		panel3.add(output);
		button1.setVisible(true);
		button2.setVisible(true);
		button3.setVisible(false);
		button4.setVisible(false);
		button5.setVisible(false);
		button6.setVisible(false);
		button7.setVisible(false);
		button8.setVisible(false);
		textarea.setVisible(false);
		key.setVisible(false);
		iv.setVisible(false);
		output.setVisible(false);
		label1.setVisible(false);
		label2.setVisible(false);
		label3.setVisible(false);
		label4.setVisible(false);
		label5.setVisible(false);
		// ECB模式
		ActionListener C = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				button1.setVisible(false);
				button2.setVisible(false);
				button3.setVisible(true);
				button5.setVisible(true);
				button7.setVisible(true);
				button8.setVisible(true);
				textarea.setVisible(true);
				// label1.setVisible(true);
				// output.setVisible(true);
				label3.setVisible(true);
				label4.setVisible(true);
				key.setVisible(true);
				textarea.setText("");
				key.setText("");
			}
		};
		// CBC模式
		button1.addActionListener(C);

		ActionListener D = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				button1.setVisible(false);
				button2.setVisible(false);
				button4.setVisible(true);
				button6.setVisible(true);
				button7.setVisible(true);
				button8.setVisible(true);
				textarea.setVisible(true);
				label3.setVisible(true);
				label4.setVisible(true);
				label5.setVisible(true);
				// label2.setVisible(true);
				// output.setVisible(true);
				key.setVisible(true);
				iv.setVisible(true);
				textarea.setText("");
				key.setText("");
				iv.setText("");
			}
		};
		button2.addActionListener(D);
		// ECB模式加密
		ActionListener ECB_C = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				String plainText = textarea.getText();
				String keyText = key.getText();
				if (keyText.length() == 16) {
					label1.setVisible(true);
					label2.setVisible(false);
					output.setVisible(true);
					SM4Utils sm4 = new SM4Utils();
					sm4.secretKey = keyText;
					sm4.hexString = false;
					String cipherText = sm4.encryptData_ECB(plainText);
					output.setText(cipherText);
					// textarea.setText("");
					// key.setText(" ");
				} else {
					JOptionPane.showMessageDialog(null, "密钥应为16位字符串！", "出错了", JOptionPane.ERROR_MESSAGE);
				}
			}
		};
		button3.addActionListener(ECB_C);

		// CBC模式加密
		ActionListener CBC_C = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				String plainText = textarea.getText();
				String keyText = key.getText();
				String ivText = iv.getText();
				if (keyText.length() == 16 && ivText.length() == 16) {
					label1.setVisible(true);
					label2.setVisible(false);
					output.setVisible(true);
					SM4Utils sm4 = new SM4Utils();
					sm4.secretKey = keyText;
					sm4.hexString = false;
					sm4.iv = ivText;
					String cipherText = sm4.encryptData_CBC(plainText);
					output.setText(cipherText);
				} else {
					JOptionPane.showMessageDialog(null, "密钥及iv值应为16位字符串！", "出错了", JOptionPane.ERROR_MESSAGE);
				}
			}
		};
		button4.addActionListener(CBC_C);
		// ECB模式解密
		ActionListener ECB_E = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				String plainText = textarea.getText();
				String keyText = key.getText();
				if (keyText.length() == 16) {
					label1.setVisible(false);
					label2.setVisible(true);
					output.setVisible(true);
					SM4Utils sm4 = new SM4Utils();
					sm4.secretKey = keyText;
					sm4.hexString = false;
					String cipherText = sm4.decryptData_ECB(plainText);
					output.setText(cipherText);
				} else {
					JOptionPane.showMessageDialog(null, "密钥应为16位字符串！", "出错了", JOptionPane.ERROR_MESSAGE);
				}
			}
		};
		button5.addActionListener(ECB_E);
		// CBC模式解密
		ActionListener CBC_E = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				String plainText = textarea.getText();
				String keyText = key.getText();
				String ivText = iv.getText();
				if (keyText.length() == 16 && ivText.length() == 16) {
					label1.setVisible(false);
					label2.setVisible(true);
					output.setVisible(true);
					SM4Utils sm4 = new SM4Utils();
					sm4.secretKey = keyText;
					sm4.hexString = false;
					sm4.iv = ivText;
					String cipherText = sm4.decryptData_CBC(plainText);
					output.setText(cipherText);
				} else {
					JOptionPane.showMessageDialog(null, "密钥及iv值应为16位字符串！", "出错了", JOptionPane.ERROR_MESSAGE);
				}
			}
		};
		button6.addActionListener(CBC_E);
		// 清空输入框
		ActionListener clean = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				textarea.setText("");
				key.setText("");
				iv.setText("");
				output.setText("");
				output.setVisible(false);
			}
		};
		button7.addActionListener(clean);

		// 返回
		ActionListener RESM4 = new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				button1.setVisible(true);
				button2.setVisible(true);
				button3.setVisible(false);
				button4.setVisible(false);
				button5.setVisible(false);
				button6.setVisible(false);
				button7.setVisible(false);
				button8.setVisible(false);
				textarea.setVisible(false);
				key.setVisible(false);
				iv.setVisible(false);
				output.setVisible(false);
				label1.setVisible(false);
				label2.setVisible(false);
				label3.setVisible(false);
				label4.setVisible(false);
				label5.setVisible(false);
			}
		};
		button8.addActionListener(RESM4);
	}

	private void setTextAreaFont(JTextArea textArea) {
		Font font = new Font("宋体", Font.PLAIN, 13);
		textArea.setMargin(new Insets(10, 10, 10, 10));
		textArea.setColumns(90);
		textArea.setLineWrap(false);
		textArea.setFont(font);
	}

	private void SM9Frame1() throws Exception {
		// 签名
		final JLabel labelMSignPriKey = new JLabel("签名主私钥：");
		final JLabel labelID = new JLabel("实体A标识 ：");
		final JLabel labelMSignPubKey = new JLabel("签名主公钥：");
		final JLabel labelSignPriKey = new JLabel("实体的签名私钥：");
		final JLabel labelSignPlain = new JLabel("待加密消息M：");
		final JLabel labelSignature = new JLabel("消息M的签名为(h,s):");

		// 签名
		final JTextArea textMSignPriKey = new JTextArea();
		final JTextArea textID = new JTextArea();
		// final JTextArea textIdentify = new JTextArea();
		final JTextArea textMSignPubKey = new JTextArea();
		final JTextArea curveTextArea = new JTextArea();// 最下面
		final JTextArea textSignPriKey = new JTextArea();
		final JTextArea textSignPlain = new JTextArea();
		// final JTextArea textRandom = new JTextArea();
		final JTextArea textSignature = new JTextArea();

		// 签名
		final JButton buttonMSignPair = new JButton("生成随机签名密钥对");
		final JButton buttonSignPair = new JButton("生成实体的私钥");
		final JButton buttonSign = new JButton("签名");
		final JButton buttonCheckSign = new JButton("验证签名");
		// final JButton buttonSign = new JButton("生成随机签名密钥对");

		final JScrollPane scrollPane = new JScrollPane(curveTextArea);

		final JSeparator separator1 = new JSeparator(SwingConstants.HORIZONTAL);

		// 签名
		textMSignPriKey.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textID.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		// textIdentify.setBorder(BorderFactory.createLineBorder(Color.gray,
		// 1));
		textMSignPubKey.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		curveTextArea.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textSignPriKey.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textSignPlain.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		// textRandom.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textSignature.setBorder(BorderFactory.createLineBorder(Color.gray, 1));

		panelSM9Sign.setLayout(new GridBagLayout());

		// 签名
		setTextAreaFont(textID);
		// setTextAreaFont(textIdentify);
		setTextAreaFont(textMSignPriKey);
		setTextAreaFont(textMSignPubKey);
		setTextAreaFont(curveTextArea);
		setTextAreaFont(textSignPriKey);
		setTextAreaFont(textSignPlain);
		// setTextAreaFont(textRandom);
		setTextAreaFont(textSignature);

		// 封装
		final JLabel labelencryptMasterpriKey = new JLabel("加密主私钥：");
		final JLabel labelencryptpubKey = new JLabel("加密主公钥：");
		final JLabel labelBID = new JLabel("实体B标识 ：");
		final JLabel labelencryptpriKey = new JLabel("加密私钥：");
		final JLabel labelkeyByteLen = new JLabel("封装密钥长度：");
		final JLabel labelkeyEncapsulation = new JLabel("密钥封装结果:");
		final JLabel labelkeyDecapsulate = new JLabel("解封后的密钥：");
		// 封装
		final JTextArea textencryptMasterpriKey = new JTextArea();
		final JTextArea textencryptMasterpubKey = new JTextArea();
		final JTextArea textBID = new JTextArea();
		final JTextArea textencryptpriKey = new JTextArea();
		final JTextArea textkeyByteLen = new JTextArea();
		final JTextArea textkeyEncapsulation = new JTextArea();
		final JTextArea textkeyDecapsulate = new JTextArea();
		// 封装
		final JButton buttonMasterKey = new JButton("生成密钥对");
		final JButton buttonencryptpriKey = new JButton("生成实体B的私钥");
		final JButton buttonencrypt = new JButton("密钥封装");
		final JButton buttonkeyDecapsulate = new JButton("解封");
		// final JButton buttonkeycheck = new JButton("验证");

		// 封装
		textencryptMasterpriKey.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textencryptMasterpubKey.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		// textIdentify.setBorder(BorderFactory.createLineBorder(Color.gray,
		// 1));
		textBID.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textencryptpriKey.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textkeyByteLen.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textkeyEncapsulation.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		// textRandom.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textkeyDecapsulate.setBorder(BorderFactory.createLineBorder(Color.gray, 1));

		panelSM9KeyEncap.setLayout(new GridBagLayout());

		// 封装
		setTextAreaFont(textencryptMasterpriKey);
		// setTextAreaFont(textIdentify);
		setTextAreaFont(textencryptMasterpubKey);
		setTextAreaFont(textBID);
		setTextAreaFont(textencryptpriKey);
		setTextAreaFont(textkeyByteLen);
		setTextAreaFont(textkeyEncapsulation);
		// setTextAreaFont(textRandom);
		setTextAreaFont(textkeyDecapsulate);

		{
			// 行 1
			constraints.insets = new Insets(10, 0, 0, 0);
			constraints.fill = GridBagConstraints.HORIZONTAL;
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 0;
			panelSM9Sign.add(labelMSignPriKey, constraints);
			panelSM9KeyEncap.add(labelencryptMasterpriKey, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 0;
			constraints.gridwidth = 3;
			constraints.ipady = 10;
			panelSM9Sign.add(textMSignPriKey, constraints);
			panelSM9KeyEncap.add(textencryptMasterpriKey, constraints);

			// -- 行 2
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 1;
			constraints.ipady = 50;
			panelSM9Sign.add(labelMSignPubKey, constraints);
			panelSM9KeyEncap.add(labelencryptpubKey, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 1;
			constraints.gridwidth = 3;
			constraints.ipady = 10;
			panelSM9Sign.add(textMSignPubKey, constraints);
			panelSM9KeyEncap.add(textencryptMasterpubKey, constraints);

			// 行 3
			constraints.ipady = 0;
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 2;
			constraints.gridwidth = 1;
			panelSM9Sign.add(labelID, constraints);
			panelSM9KeyEncap.add(labelBID, constraints);

			constraints.weightx = 0.1;
			constraints.gridx = 1;
			constraints.gridy = 2;
			constraints.gridwidth = 1;
			constraints.ipady = 10;
			panelSM9Sign.add(textID, constraints);
			panelSM9KeyEncap.add(textBID, constraints);

			// 行 4
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 3;
			panelSM9Sign.add(labelSignPriKey, constraints);
			panelSM9KeyEncap.add(labelencryptpriKey, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 3;
			constraints.gridwidth = 3;
			constraints.ipady = 10;
			panelSM9Sign.add(textSignPriKey, constraints);
			panelSM9KeyEncap.add(textencryptpriKey, constraints);

			// line 5
			constraints.ipady = 0;
			constraints.fill = GridBagConstraints.HORIZONTAL;
			constraints.gridx = 0;
			constraints.gridy = 4;
			constraints.gridwidth = 4;
			panelSM9Sign.add(separator1, constraints);

			// line 5
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 5;
			panelSM9Sign.add(labelSignPlain, constraints);
			panelSM9KeyEncap.add(labelkeyByteLen, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 5;
			constraints.gridwidth = 3;
			constraints.ipady = 10;
			panelSM9Sign.add(textSignPlain, constraints);
			panelSM9KeyEncap.add(textkeyByteLen, constraints);

			// line 6
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 6;
			constraints.ipady = 0;
			panelSM9KeyEncap.add(labelkeyEncapsulation, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 6;
			constraints.gridwidth = 3;
			constraints.ipady = 10;
			panelSM9KeyEncap.add(textkeyEncapsulation, constraints);

			// line 7
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 7;
			constraints.ipady = 0;
			panelSM9KeyEncap.add(labelkeyDecapsulate, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 7;
			constraints.gridwidth = 3;
			constraints.ipady = 10;
			panelSM9KeyEncap.add(textkeyDecapsulate, constraints);

			// line 7
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 7;
			constraints.ipady = 30;
			panelSM9Sign.add(labelSignature, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 7;
			constraints.gridwidth = 3;
			constraints.ipady = 10;
			panelSM9Sign.add(textSignature, constraints);

			// 按钮
			constraints.ipady = 0;
			constraints.fill = GridBagConstraints.HORIZONTAL;
			constraints.weightx = 0.2;
			constraints.gridx = 0;
			constraints.gridy = 8;
			constraints.gridwidth = 1;
			panelSM9Sign.add(buttonMSignPair, constraints);
			panelSM9KeyEncap.add(buttonMasterKey, constraints);

			constraints.weightx = 0.2;
			constraints.gridx = 1;
			constraints.gridy = 8;
			constraints.gridwidth = 1;
			panelSM9Sign.add(buttonSignPair, constraints);
			panelSM9KeyEncap.add(buttonencryptpriKey, constraints);

			constraints.weightx = 0.2;
			constraints.gridx = 2;
			constraints.gridy = 8;
			constraints.gridwidth = 1;
			panelSM9Sign.add(buttonSign, constraints);
			panelSM9KeyEncap.add(buttonencrypt, constraints);

			constraints.weightx = 0.2;
			constraints.gridx = 3;
			constraints.gridy = 8;
			constraints.gridwidth = 1;
			panelSM9Sign.add(buttonCheckSign, constraints);
			panelSM9KeyEncap.add(buttonkeyDecapsulate, constraints);

			// 文本框
			constraints.ipady = 200; // RESET
			constraints.weightx = 0.0;
			constraints.insets = new Insets(10, 0, 0, 0);
			constraints.gridwidth = 4;
			constraints.gridx = 0; // 水平是x
			constraints.gridy = 9;
			panelSM9Sign.add(scrollPane, constraints);

		}

		SM9Curve sm9Curve = new SM9Curve();
		KGC kgc = new KGC(sm9Curve);
		SM9 sm9 = new SM9(sm9Curve);
		String msg = "Chinese IBS standard";
		int keyByteLen = 32;
		/*
		 * 签名测试：
		 */
		setSM9CurveParas(sm9Curve.toString(), curveTextArea);// 最下面文本框
		setSM9TextID("China", textID);
		// 生成签名主密钥对
		MasterKeyPair signMasterKeyPair = kgc.genSignMasterKeyPair();
		// 实体关联的签名密钥
		PrivateKey signPrivateKey = kgc.genPrivateKey(signMasterKeyPair.getPrivateKey(), textID.getText(),
				PrivateKeyType.KEY_SIGN);
		setSM9TextSignPlain(msg, textSignPlain);// 待加密消息
		// 签名按钮
		buttonMSignPair.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setSM9TextMSignPubKey(signMasterKeyPair.getPublicKey().toString(), textMSignPubKey);
				setSM9TextMSignPriKey(signMasterKeyPair.getPrivateKey().toString(), textMSignPriKey);
			}
		});
		buttonSignPair.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setSM9TextSignPriKey(signPrivateKey.toString(), textSignPriKey);
			}
		});
		buttonSign.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// SM9WithStandardTestKey.r = new
				// BigInteger(textRandom.getText(), 16);
				ResultSignature signature = sm9.sign(signMasterKeyPair.getPublicKey(), signPrivateKey,
						textSignPlain.getText().getBytes());
				setSignResult(signature);
				textSignature.setText(signature.toString());
			}
		});
		buttonCheckSign.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (sm9.verify(signMasterKeyPair.getPublicKey(), textID.getText(), textSignPlain.getText().getBytes(),
						signature)) {
					// Main.showMsg("verify OK");
					JOptionPane.showMessageDialog(UI.this, "验证通过");
				} else {
					// Main.showMsg("verify failed");
					JOptionPane.showMessageDialog(UI.this, "验证失败", "信息", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		/*
		 * 加解密：
		 */

		/*
		 * 封装：
		 */
		setSM9CurveParas(sm9Curve.toString(), curveTextArea);// 最下面文本框
		setSM9TextBID("Bob", textBID);
		setkeyByteLen(keyByteLen, textkeyByteLen);// 待加密消息
		// 生成主密钥对
		MasterKeyPair encryptMasterKeyPair = kgc.genEncryptMasterKeyPair();
		// 实体关联的密钥
		PrivateKey encryptPrivateKey = kgc.genPrivateKey(encryptMasterKeyPair.getPrivateKey(), textBID.getText(),
				PrivateKeyType.KEY_ENCRYPT);
		// 封装按钮
		buttonMasterKey.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setencryptMasterpriKey(encryptMasterKeyPair.getPublicKey().toString(), textencryptMasterpriKey);
				setencryptMasterpubKey(encryptMasterKeyPair.getPrivateKey().toString(), textencryptMasterpubKey);
			}

		});
		buttonencryptpriKey.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				setencryptpriKey(encryptPrivateKey.toString(), textencryptpriKey);
			}

		});
		buttonencrypt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ResultEncapsulate keyEncapsulation = sm9.keyEncapsulate(encryptMasterKeyPair.getPublicKey(),
						textBID.getText(), keyByteLen);
				setEncapsulateResult(keyEncapsulation);
				textkeyEncapsulation.setText(keyEncapsulation.toString());
			}

		});
		buttonkeyDecapsulate.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				ResultEncapsulateCipherText cipherText = ResultEncapsulateCipherText.fromByteArray(sm9.getCurve(),
						keyEncapsulation.getC().toByteArray());
				byte[] K = null;
				try {
					K = sm9.keyDecapsulate(encryptPrivateKey, textBID.getText(), keyByteLen, cipherText);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				setkeyDecapsulate(cipherText);
				textkeyDecapsulate.setText(SM9Utils.toHexString(K));
			}

			private void setkeyDecapsulate(ResultEncapsulateCipherText cipherText) {
				// TODO Auto-generated method stub

			}

		});

		/*
		 * 密钥交换：
		 */

	}

	// --封装
	private void setkeyByteLen(int keyByteLen, JTextArea textkeyByteLen) {
		// TODO Auto-generated method stub
		textkeyByteLen.setText(Integer.toString(keyByteLen));
	}

	private void setSM9TextBID(String id, JTextArea textBID) {
		// TODO Auto-generated method stub
		textBID.setText(id);
	}

	private void setencryptMasterpubKey(String toString, JTextArea textencryptMasterpubKey) {
		// TODO Auto-generated method stub
		textencryptMasterpubKey.setText(toString);
	}

	private void setencryptMasterpriKey(String toString, JTextArea textencryptMasterpriKey) {
		// TODO Auto-generated method stub
		textencryptMasterpriKey.setText(toString);
	}

	private void setencryptpriKey(String toString, JTextArea textencryptpriKey) {
		// TODO Auto-generated method stub
		textencryptpriKey.setText(toString);
	}

	private void setEncapsulateResult(ResultEncapsulate keyEncapsulation) {
		// TODO Auto-generated method stub
		this.keyEncapsulation = keyEncapsulation;

	}

	// --封装完
	// --签名
	private void setSM9TextSignPlain(String toString, JTextArea textSignPlain) {
		// TODO Auto-generated method stub
		textSignPlain.setText(toString);
	}

	private void setSignResult(ResultSignature signature) {
		this.signature = signature;
	}

	private void setSM9TextSignPriKey(String toString, JTextArea textSignPriKey) {
		textSignPriKey.setText(toString);
	}

	private void setSM9TextMSignPriKey(String toString, JTextArea textMSignPriKey) {
		textMSignPriKey.setText(toString);
	}

	private void setSM9TextMSignPubKey(String toString, JTextArea textMSignPubKey) {
		textMSignPubKey.setText(toString);
	}

	private void setSM9TextID(String id, JTextArea textID) {
		textID.setText(id);
	}

	public void setSM9CurveParas(String curvePara, JTextArea curveTextArea) {
		curveTextArea.setText(curvePara);
	}
	// --签名完

	// 加解密
	private void SM9Frame2() throws Exception {
		final JLabel labelMEncryptPriKey = new JLabel("加密主私钥：");
		final JLabel labelID = new JLabel("实体标识 ID：");
		final JLabel labelMEncryptPubKey = new JLabel("加密主公钥：");
		final JLabel labelEncryptPriKey = new JLabel("加密私钥：");
		final JLabel labelPlain = new JLabel("待加密原文：");
		final JLabel labelCipher = new JLabel("加密后密文：");
		final JLabel labelRes = new JLabel("解密结果:");

		final JTextArea textMEncryptPriKey = new JTextArea();
		final JTextArea textID = new JTextArea();
		final JTextArea textMEncryptPubKey = new JTextArea();
		final JTextArea textEncryptPriKey = new JTextArea();
		final JTextArea textPlain = new JTextArea();
		final JTextArea textCipher = new JTextArea();
		final JTextArea textRes = new JTextArea();

		final JButton buttonPair = new JButton("生成密钥对");
		final JButton buttonPri = new JButton("生成私钥");
		final JButton buttonEncrypt = new JButton("加密");
		final JButton buttonDe = new JButton("解密");

		// final JScrollPane scrollPane = new JScrollPane(curveTextArea);

		// final JSeparator separator11 = new
		// JSeparator(SwingConstants.HORIZONTAL);

		textMEncryptPriKey.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textID.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textMEncryptPubKey.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textEncryptPriKey.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textPlain.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textCipher.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textRes.setBorder(BorderFactory.createLineBorder(Color.gray, 1));

		panelSM9Encrypt.setLayout(new GridBagLayout());

		setTextAreaFont(textMEncryptPriKey);
		setTextAreaFont(textID);
		setTextAreaFont(textMEncryptPubKey);
		setTextAreaFont(textEncryptPriKey);
		setTextAreaFont(textPlain);
		setTextAreaFont(textCipher);
		setTextAreaFont(textRes);

		{
			// 行 1
			constraints.insets = new Insets(10, 0, 0, 0);
			constraints.fill = GridBagConstraints.HORIZONTAL;
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 0;
			constraints.ipady = 10;
			panelSM9Encrypt.add(labelMEncryptPriKey, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 0;
			constraints.gridwidth = 3;
			panelSM9Encrypt.add(textMEncryptPriKey, constraints);

			// -- 行 2
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 1;
			constraints.ipady = 0;
			panelSM9Encrypt.add(labelID, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 1;
			constraints.gridwidth = 3;
			panelSM9Encrypt.add(textID, constraints);

			// 行 3
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 2;
			panelSM9Encrypt.add(labelMEncryptPubKey, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 2;
			constraints.gridwidth = 3;
			constraints.ipady = 10;
			panelSM9Encrypt.add(textMEncryptPubKey, constraints);

			// 行 4
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 3;
			panelSM9Encrypt.add(labelEncryptPriKey, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 3;
			constraints.gridwidth = 3;
			constraints.ipady = 20;
			panelSM9Encrypt.add(textEncryptPriKey, constraints);

			// line 5
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 4;
			panelSM9Encrypt.add(labelPlain, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 4;
			constraints.gridwidth = 3;
			constraints.ipady = 20;
			panelSM9Encrypt.add(textPlain, constraints);

			// // line 6
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 5;
			panelSM9Encrypt.add(labelCipher, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 5;
			constraints.gridwidth = 3;
			constraints.ipady = 20;
			panelSM9Encrypt.add(textCipher, constraints);

			// line 7
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 6;
			constraints.ipady = 0;
			panelSM9Encrypt.add(labelRes, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 6;
			constraints.ipady = 20;
			constraints.gridwidth = 3;
			panelSM9Encrypt.add(textRes, constraints);

			// button line 8
			constraints.ipady = 0;
			constraints.fill = GridBagConstraints.HORIZONTAL;
			constraints.weightx = 0.2;
			constraints.gridx = 0;
			constraints.gridy = 7;
			constraints.gridwidth = 1;
			panelSM9Encrypt.add(buttonPair, constraints);

			constraints.weightx = 0.2;
			constraints.gridx = 1;
			constraints.gridy = 7;
			constraints.gridwidth = 1;
			panelSM9Encrypt.add(buttonPri, constraints);

			constraints.weightx = 0.2;
			constraints.gridx = 2;
			constraints.gridy = 7;
			constraints.gridwidth = 1;
			panelSM9Encrypt.add(buttonEncrypt, constraints);

			constraints.weightx = 0.2;
			constraints.gridx = 3;
			constraints.gridy = 7;
			constraints.gridwidth = 1;
			panelSM9Encrypt.add(buttonDe, constraints);

		}
		setSM9TextID("China", textID);
		// 生成加密用密钥对
		SM9Curve sm9Curve = new SM9Curve();
		KGC kgc = new KGC(sm9Curve);
		SM9 sm9 = new SM9(sm9Curve);
		String msg = "Chinese IBS standard";
		setSM9TextSignPlain(msg, textPlain);// 待加密消息
		MasterKeyPair encryptMasterKeyPair = kgc.genEncryptMasterKeyPair();

		buttonPair.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				textMEncryptPriKey.setText(encryptMasterKeyPair.getPrivateKey().toString());
				textMEncryptPubKey.setText(encryptMasterKeyPair.getPublicKey().toString());
			}

		});

		buttonPri.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				PrivateKey encryptPrivateKey = null;
				try {
					encryptPrivateKey = kgc.genPrivateKey(encryptMasterKeyPair.getPrivateKey(), textID.getText(),
							PrivateKeyType.KEY_ENCRYPT);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				setEncryptrivateKey(encryptPrivateKey);
				textEncryptPriKey.setText(encryptPrivateKey.toString());
			}

		});

		int macKeyByteLen = 32;

		buttonEncrypt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// String plainText = textPlain.getText();
				ResultCipherText resultCipherText = null;
				try {
					resultCipherText = sm9.encrypt(encryptMasterKeyPair.getPublicKey(), textID.getText(),
							textPlain.getText().getBytes(), false, macKeyByteLen);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				setResultCipherText(resultCipherText);
				textCipher.setText(SM9Utils.toHexString(resultCipherText.toByteArray()));
			}

		});

		buttonDe.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					byte[] msgd = sm9.decrypt(getResultCipherText(), getEncryptrivateKey(), textID.getText(), false,
							macKeyByteLen);
					System.out.println(Arrays.toString(textPlain.getText().getBytes()));
					System.out.println(Arrays.toString(msgd));

					if (SM9Utils.byteEqual(textPlain.getText().getBytes(), msgd)) {
						JOptionPane.showMessageDialog(UI.this, "验证通过");
						textRes.setText(new String(msgd));
					} else {
						JOptionPane.showMessageDialog(UI.this, "验证失败", "信息", JOptionPane.ERROR_MESSAGE);
					}

				} catch (Exception ex) {
					ex.printStackTrace();
				}

			}

		});

	}

	// --解密完

	// SM9 密钥交换
	private void SM9Frame3() {
		final JLabel labelMEncryptPriKey = new JLabel("加密主私钥：");
		final JLabel labelAID = new JLabel("实体A标识 ID：");
		final JLabel labelBID = new JLabel("实体B标识 ID：");
		final JLabel labelMEncryptPubKey = new JLabel("加密主公钥：");
		final JLabel labelAPriKey = new JLabel("实体A私钥：");
		final JLabel labelBPriKey = new JLabel("实体B私钥：");
		final JLabel labelKeyLength = new JLabel("密钥长度");
		final JLabel labelASA2 = new JLabel("实体A SA2");
		final JLabel labelASB1 = new JLabel("实体A SB1");
		final JLabel labelASK = new JLabel("实体A SK");
		final JLabel labelBSA2 = new JLabel("实体B SA2");
		final JLabel labelBSB1 = new JLabel("实体B SB1");
		final JLabel labelBSK = new JLabel("实体B SK");

		final JTextArea textMEncryptPriKey = new JTextArea();
		final JTextArea textAID = new JTextArea();
		final JTextArea textBID = new JTextArea();
		final JTextArea textMEncryptPubKey = new JTextArea();
		final JTextArea textAPriKey = new JTextArea();
		final JTextArea textBPriKey = new JTextArea();
		final JTextArea textKeyLength = new JTextArea();
		final JTextArea textASA2 = new JTextArea();
		final JTextArea textASB1 = new JTextArea();
		final JTextArea textASK = new JTextArea();
		final JTextArea textBSK = new JTextArea();
		final JTextArea textBSA2 = new JTextArea();
		final JTextArea textBSB1 = new JTextArea();

		final JButton buttonPair = new JButton("生成密钥对");
		final JButton buttonPri = new JButton("生成实体的私钥");
		final JButton buttonExchange = new JButton("密钥交换");

		final JSeparator separator1 = new JSeparator(SwingConstants.HORIZONTAL);

		textMEncryptPriKey.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textAID.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textBID.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textMEncryptPubKey.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textAPriKey.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textBPriKey.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textKeyLength.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textASA2.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textASB1.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textASK.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textBSK.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textBSA2.setBorder(BorderFactory.createLineBorder(Color.gray, 1));
		textBSB1.setBorder(BorderFactory.createLineBorder(Color.gray, 1));

		panelSM9Exchange.setLayout(new GridBagLayout());

		setTextAreaFont(textMEncryptPriKey);
		setTextAreaFont(textAID);
		setTextAreaFont(textBID);
		setTextAreaFont(textMEncryptPubKey);
		setTextAreaFont(textAPriKey);
		setTextAreaFont(textBPriKey);
		setTextAreaFont(textKeyLength);
		setTextAreaFont(textASA2);
		setTextAreaFont(textASB1);
		setTextAreaFont(textASK);
		setTextAreaFont(textBSK);
		setTextAreaFont(textBSA2);
		setTextAreaFont(textBSB1);

		{
			// 行 1
			constraints.insets = new Insets(10, 0, 0, 0);
			constraints.fill = GridBagConstraints.HORIZONTAL;
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 0;
			constraints.ipady = 10;
			panelSM9Exchange.add(labelMEncryptPriKey, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 0;
			constraints.gridwidth = 3;
			panelSM9Exchange.add(textMEncryptPriKey, constraints);

			// -- 行 2
			constraints.weightx = 0.2;
			constraints.gridx = 0;
			constraints.gridy = 1;
			constraints.ipady = 0;
			constraints.gridwidth = 1;

			panelSM9Exchange.add(labelAID, constraints);

			constraints.weightx = 0.2;
			constraints.gridx = 1;
			constraints.gridy = 1;
			constraints.gridwidth = 1;
			panelSM9Exchange.add(textAID, constraints);

			constraints.weightx = 0.2;
			constraints.gridx = 2;
			constraints.gridy = 1;
			constraints.gridwidth = 1;
			panelSM9Exchange.add(labelBID, constraints);

			constraints.weightx = 0.2;
			constraints.gridx = 3;
			constraints.gridy = 1;
			constraints.gridwidth = 1;
			panelSM9Exchange.add(textBID, constraints);

			// 行 3
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 2;
			panelSM9Exchange.add(labelMEncryptPubKey, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 2;
			constraints.gridwidth = 3;
			constraints.ipady = 10;
			panelSM9Exchange.add(textMEncryptPubKey, constraints);

			// 行 4
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 3;
			constraints.gridwidth = 1;
			panelSM9Exchange.add(labelAPriKey, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 3;
			constraints.gridwidth = 3;
			constraints.ipady = 10;
			panelSM9Exchange.add(textAPriKey, constraints);

			// line 5
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 4;
			constraints.gridwidth = 1;
			panelSM9Exchange.add(labelBPriKey, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 4;
			constraints.gridwidth = 3;
			constraints.ipady = 10;
			panelSM9Exchange.add(textBPriKey, constraints);

			// // line 6
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 5;
			panelSM9Exchange.add(labelKeyLength, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 5;
			constraints.gridwidth = 3;
			constraints.ipady = 10;
			panelSM9Exchange.add(textKeyLength, constraints);

			// line 7
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 6;
			panelSM9Exchange.add(labelASA2, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 6;
			constraints.ipady = 10;
			constraints.gridwidth = 3;
			panelSM9Exchange.add(textASA2, constraints);

			// 8
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 7;
			panelSM9Exchange.add(labelASB1, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 7;
			constraints.ipady = 10;
			constraints.gridwidth = 3;
			panelSM9Exchange.add(textASB1, constraints);

			// 9
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 8;
			panelSM9Exchange.add(labelASK, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 8;
			constraints.ipady = 10;
			constraints.gridwidth = 3;
			panelSM9Exchange.add(textASK, constraints);

			// 10
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 9;
			panelSM9Exchange.add(labelBSA2, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 9;
			constraints.ipady = 10;
			constraints.gridwidth = 3;
			panelSM9Exchange.add(textBSA2, constraints);

			// 11
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 10;
			panelSM9Exchange.add(labelBSB1, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 10;
			constraints.ipady = 10;
			constraints.gridwidth = 3;
			panelSM9Exchange.add(textBSB1, constraints);

			// 12
			constraints.weightx = 0.1;
			constraints.gridx = 0;
			constraints.gridy = 11;
			panelSM9Exchange.add(labelBSK, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 1;
			constraints.gridy = 11;
			constraints.ipady = 10;
			constraints.gridwidth = 3;
			panelSM9Exchange.add(textBSK, constraints);

			// button line 13
			constraints.ipady = 0;
			constraints.fill = GridBagConstraints.HORIZONTAL;
			constraints.weightx = 0.2;
			constraints.gridx = 0;
			constraints.gridy = 12;
			constraints.gridwidth = 1;
			panelSM9Exchange.add(buttonPair, constraints);

			constraints.weightx = 0.2;
			constraints.gridx = 1;
			constraints.gridy = 12;
			constraints.gridwidth = 1;
			panelSM9Exchange.add(buttonPri, constraints);

			constraints.weightx = 0.2;
			constraints.gridx = 2;
			constraints.gridy = 12;
			constraints.gridwidth = 1;
			panelSM9Exchange.add(buttonExchange, constraints);

		}
		SM9Curve sm9Curve = new SM9Curve();
		KGC kgc = new KGC(sm9Curve);
		SM9 sm9 = new SM9(sm9Curve);
		textAID.setText("Tom");
		textBID.setText("Jerry");
		int keyByteLen = 16;
		textKeyLength.setText(keyByteLen + "");
		MasterKeyPair masterKeyPair = kgc.genEncryptMasterKeyPair();
		// Main.showMsg("加密主私钥 ke:");
		// Main.showMsg(masterKeyPair.getPrivateKey().toString());
		// Main.showMsg("加密主公钥 Ppub-e:");
		// Main.showMsg(masterKeyPair.getPublicKey().toString());
		buttonPair.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				textMEncryptPriKey.setText(masterKeyPair.getPrivateKey().toString());
				textMEncryptPubKey.setText(masterKeyPair.getPublicKey().toString());
			}
		});

		buttonPri.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				PrivateKey aPrivateKey = null;
				PrivateKey bPrivateKey = null;
				try {
					aPrivateKey = kgc.genPrivateKey(masterKeyPair.getPrivateKey(), textAID.getText(),
							PrivateKeyType.KEY_KEY_EXCHANGE);
					bPrivateKey = kgc.genPrivateKey(masterKeyPair.getPrivateKey(), textBID.getText(),
							PrivateKeyType.KEY_KEY_EXCHANGE);
					setaPrivateKey(aPrivateKey);
					setbPrivateKey(bPrivateKey);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
				// Main.showMsg(myPrivateKey.toString());
				textAPriKey.setText(aPrivateKey.toString());
				textBPriKey.setText(bPrivateKey.toString());

			}
		});

		buttonExchange.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				SM9WithStandardTestKey.r = new BigInteger(
						"5879DD1D51E175946F23B1B41E93BA31C584AE59A426EC1046A4D03B06C8", 16);
				G1KeyPair myTempKeyPair = sm9.keyExchangeInit(masterKeyPair.getPublicKey(), textBID.getText());

				SM9WithStandardTestKey.r = new BigInteger(
						"018B98C44BEF9F8537FB7D071B2C928B3BC65BD3D69E1EEE213564905634FE", 16);
				G1KeyPair othTempKeyPair = sm9.keyExchangeInit(masterKeyPair.getPublicKey(), textAID.getText());

				ResultKeyExchange othAgreementKey = null;
				try {
					othAgreementKey = sm9.keyExchange(masterKeyPair.getPublicKey(), false, textBID.getText(),
							textAID.getText(), getbPrivateKey(), othTempKeyPair, myTempKeyPair.getPublicKey(),
							keyByteLen);
				} catch (Exception ex) {
					ex.printStackTrace();
				}

				ResultKeyExchange myAgreementKey = null;
				try {
					myAgreementKey = sm9.keyExchange(masterKeyPair.getPublicKey(), true, textAID.getText(),
							textBID.getText(), getaPrivateKey(), myTempKeyPair, othTempKeyPair.getPublicKey(),
							keyByteLen);
				} catch (Exception ex) {
					ex.printStackTrace();
				}

				textASA2.setText(SM9Utils.toHexString(myAgreementKey.getSA2()));
				textASB1.setText(SM9Utils.toHexString(myAgreementKey.getSB1()));
				textASK.setText(SM9Utils.toHexString(myAgreementKey.getSK()));

				textBSA2.setText(SM9Utils.toHexString(othAgreementKey.getSA2()));
				textBSB1.setText(SM9Utils.toHexString(othAgreementKey.getSB1()));
				textBSK.setText(SM9Utils.toHexString(othAgreementKey.getSK()));

				boolean isSuccess = true;
				if (SM9Utils.byteEqual(myAgreementKey.getSA2(), othAgreementKey.getSA2()))
					Main.showMsg("SA = S2");
				else {
					Main.showMsg("SA != S2");
					isSuccess = false;
				}

				if (SM9Utils.byteEqual(myAgreementKey.getSB1(), othAgreementKey.getSB1()))
					Main.showMsg("S1 = SB");
				else {
					Main.showMsg("S1 != SB");
					isSuccess = false;
				}

				if (SM9Utils.byteEqual(myAgreementKey.getSK(), othAgreementKey.getSK()))
					Main.showMsg("SK_A = SK_B");
				else {
					Main.showMsg("SK_A != SK_B");
					isSuccess = false;
				}

				if (isSuccess)
					JOptionPane.showMessageDialog(UI.this, "交换成功");
				else {
					JOptionPane.showMessageDialog(UI.this, "交换失败", "信息", JOptionPane.ERROR_MESSAGE);
				}

			}
		});
	}

	private void ZUCFrame() throws Exception {

		final JButton button1 = new JButton("密钥加载");
		final JButton button2 = new JButton("初始化");
		final JButton button3 = new JButton("工作");
		final JButton button4 = new JButton("产生密钥流");
		final JTextArea textzuc = new JTextArea();

		textzuc.setBorder(BorderFactory.createLineBorder(Color.gray, 1));

		panelzuc.setLayout(new GridBagLayout());

		setTextAreaFont(textzuc);
		{
			// 按钮
			constraints.ipady = 0;
			constraints.fill = GridBagConstraints.HORIZONTAL;
			constraints.weightx = 0.2;
			constraints.gridx = 0;
			constraints.gridy = 0;
			constraints.gridwidth = 1;
			panelzuc.add(button1, constraints);

			constraints.weightx = 0.2;
			constraints.gridx = 1;
			constraints.gridy = 0;
			constraints.gridwidth = 1;
			panelzuc.add(button2, constraints);

			constraints.weightx = 0.2;
			constraints.gridx = 2;
			constraints.gridy = 0;
			constraints.gridwidth = 1;
			panelzuc.add(button3, constraints);

			constraints.weightx = 0.2;
			constraints.gridx = 3;
			constraints.gridy = 0;
			constraints.gridwidth = 1;
			panelzuc.add(button4, constraints);

			constraints.weightx = 0.9;
			constraints.gridx = 0;
			constraints.gridy = 2;
			constraints.gridwidth = 4;
			constraints.ipady = 50;
			panelzuc.add(textzuc, constraints);

		}
		button1.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(UI.this, "加载成功");
			}
		});
		button2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(UI.this, "初始化完成");
			}
		});
		button3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(UI.this, "开始工作");
			}
		});
		button4.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// Converter converter = new Converter();
				// textzuc.setText(converter.mian().toHexString(keys[i]));
				int[] key = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
						0x00 };
				int[] iv = { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
						0x00 };
				int[] LFSR_S = new int[16];
				int[] F_R = new int[2];
				int[] BRC_X = new int[4];
				Converter.Initialization(key, iv, LFSR_S, F_R, BRC_X);
				int[] keys = ProductKey.GenerateKeys(LFSR_S, BRC_X, F_R, 3);
				StringBuffer sBuffer = new StringBuffer();
				for (int i = 0; i < keys.length; i++) {
					sBuffer.append(Integer.toHexString(keys[i]));
				}
				textzuc.setText(sBuffer.toString());
			}
		});

	}

	public static void main(String args[]) throws Exception {
		UI d = new UI();
		d.SM2Frame();
		d.SM3Frame();
		d.SM4Frame();
		d.SM9Frame1();
		d.SM9Frame2();
		d.SM9Frame3();
		d.ZUCFrame();

	}
}
