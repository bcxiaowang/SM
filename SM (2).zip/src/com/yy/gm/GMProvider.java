package com.yy.gm;

import java.security.Provider;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

/**
 * GM algorithm provider.
 *
 * Created by YaoYuan on 2019/1/18.
 */
public class GMProvider {
	private static Provider sProvider = null;

	/**
	 * Get GM algorithm provider.
	 *
	 * @return GM algorithm provider.
	 */
	public static Provider getProvider() {
		if (sProvider == null) {
			sProvider = new BouncyCastleProvider();
		}
		return sProvider;
	}

	private GMProvider() {
	}
}
